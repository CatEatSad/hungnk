#nho gpt la lam duoc thoi :))

